import sqlite3
from flask import Flask, request, jsonify #added to top of file
from flask_cors import CORS #added to top of file

def connect_to_db():
    conn = sqlite3.connect('personas.db')
    return conn

def crear_tabla():
    try:
        conn = connect_to_db()
        conn.execute('''
            CREATE TABLE IF NOT EXISTS personas (
                timestamp horario DEFAULT CURRENT_TIMESTAMP,
                person_id INTEGER PRIMARY KEY NOT NULL,
                cantidad INTEGER NOT NULL
                
            );
        ''')
        conn.commit()#confirmando
        print("tabla personas creada satisfactoriamente")
        conn.close()
    except sqlite3.Error as e:
        print(e)
        print("error en la creacion de la tabla personas")
    finally:
        conn.close()


crear_tabla()

#get heroes
def get_personas(conn):
    iheroe={"codigo":"error"}
    try:
        cur=conn.cursor()
        c = conn.cursor()
        iheroe= c.execute('SELECT * FROM personas').fetchall()
        conn.close()
        #iheroe={"codigo":"ok"}
    except Exception as error:
        print(error,"Error en la consulta de get heroes")
    return iheroe

def insert_personas(conn, cantidad):
    iheroe={"codigo":"error"}
    try:
        print("dentro de insert_personas",str(cantidad))
        cur=conn.cursor()
        cur.execute('INSERT INTO personas(cantidad) VALUES (?)',str(cantidad))
        conn.commit()
        
        iheroe={"codigo":"ok"}
    except Exception as error:
        print(error,"Error en la consulta de insert heroe")
    return iheroe

import cv2
import pandas as pd
from ultralytics import YOLO
from tracker import *
import cvzone
import time

model=YOLO('yolov8s.pt')

contador=1

def RGB(event, x, y, flags, param):
    if event == cv2.EVENT_MOUSEMOVE :  
        point = [x, y]
        #print(point)
  
        

cv2.namedWindow('RGB')
cv2.setMouseCallback('RGB', RGB)
cap=cv2.VideoCapture(0)


my_file = open("coco.txt", "r")
data = my_file.read()
class_list = data.split("\n") 
#print(class_list)

count=0
persondown={}
tracker=Tracker()
counter1=[]

personup={}
counter2=[]
count2=0#cantidad personas
cy1=194
cy2=220
offset=6
list=[]
conn=connect_to_db()
while True:    
    time.sleep(1)
    contador=contador+1
    if(contador %32 == 1):
        print(len(list))
        num_persons = len(list)
        insert_personas(conn, num_persons)

    ret,frame = cap.read()
    if not ret:
        break
#    frame = stream.read()

    count += 32 #iba 1
    if count % 32!= 0: #iba 6
        continue
    frame=cv2.resize(frame,(1020,500))

    


    results=model.predict(frame)
 #   print(results)
    a=results[0].boxes.data
    px=pd.DataFrame(a).astype("float")
#    print(px)
    list=[]
   
    for index,row in px.iterrows():
#        #print(row)
 
        x1=int(row[0])
        y1=int(row[1])
        x2=int(row[2])
        y2=int(row[3])
        d=int(row[5])
        
        c=class_list[d]
        if 'person' in c:
            #print([x1,y1,x2,y2])
            count2=count2 +1
            list.append([x1,y1,x2,y2])
       
        
    bbox_id=tracker.update(list)
    for bbox in bbox_id:
        x3,y3,x4,y4,id=bbox
        cx=int(x3+x4)//2
        cy=int(y3+y4)//2
        #print(id)
        cv2.circle(frame,(cx,cy),4,(255,0,255),-1)
        

    cv2.imshow("RGB", frame)
    if cv2.waitKey(1)&0xFF==27:
       # print(len(list))
       # print(list)
        break
cap.release()
cv2.destroyAllWindows()
